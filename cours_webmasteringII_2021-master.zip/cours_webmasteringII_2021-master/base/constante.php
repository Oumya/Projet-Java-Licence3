<?php
define("PI",3.14);
echo "La valeur est ".PI;
echo"<br>";
//Constantes Sytemes
            echo 'Separateur de Dossier  '.DIRECTORY_SEPARATOR. '<br>';
//Quelques Constantes Magigues
            echo 'Numéro de ligne : ' .__LINE__. '<br>';
            //Affiche le chemin du ficher et son nom
            echo 'Chemin complet du fichier : ' .__FILE__. '<br>';
            //Affiche le nom du dossier qui contient le fichier
            echo 'Dossier contenant le fichier : ' .__DIR__. '<br>';
            //Affiche à nouveau la ligne où la constante a été appelée
            echo 'Numéro de ligne : ' .__LINE__. '<br>';
            
           
            