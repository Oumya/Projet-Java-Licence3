<?php
    include 'inc/header.php'; 
     echo "Layout 2";
     echo $content_views;
    include 'inc/footer.php';