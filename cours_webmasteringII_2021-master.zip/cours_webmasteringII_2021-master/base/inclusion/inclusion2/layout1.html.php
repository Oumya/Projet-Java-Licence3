<?php
    
    include 'inc/header.php'; 
     echo "Layout 1";
    echo $content_views;

    include 'inc/footer.php';