<?php
ob_start();
    $title="vue1";
?>
   <H1>Mon Formulaire</H1>

<?php
   $content_views=ob_get_clean();
?> 