<?php
//url http://localhost/cours_php/base/tableaux/associatif/get/index.php?url=1&lien=4
echo $_GET['url'];
echo "<br>";
echo $_GET['lien'];