<?php 
      require_once(PATH_VIEWS_INC."header.php"); 
      require_once(PATH_VIEWS_INC."menu.inc.php"); 
 ?>
 
    <h1> Menu Visiteur </h1>
 <?php 
          require_once(PATH_VIEWS_INC."footer.php");
 ?>