<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?=$title?></title>
</head>
<body>
<nav>
  <ul style="display:flex;">
     <li>
        <a href="index.php?menu=vue1&layout=layout1"> Menu 1</a>
     </li>
     <li>
        <a href="index.php?menu=vue2&layout=layout2"> Menu 2</a>
     </li>
  </ul>
</nav>
Voici le Header  
<style type="text/css">
 ul{
    display: flex;
    list-style: none;
    justify-content: space-between;
    width: 40%;
 }
</style>